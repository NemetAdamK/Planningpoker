package com.example.firebasetest

class Question (val question:String){
}